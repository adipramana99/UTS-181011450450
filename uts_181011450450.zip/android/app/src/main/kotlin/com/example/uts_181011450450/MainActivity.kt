package com.example.uts_181011450450

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
